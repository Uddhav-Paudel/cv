import{q as t}from"./CRcb1iVj.js";const i=t("v-list-item-title");export{i as V};
